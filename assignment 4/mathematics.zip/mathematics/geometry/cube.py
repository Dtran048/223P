def surface_area(side):
    if side.isdigit() == False:
        return("input valid number")
    return(side * side * 6)

def volume(side):
    if side.isdigit() == False:
        return("input valid number")
    return(side * side * side)

