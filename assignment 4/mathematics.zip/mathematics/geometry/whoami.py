def getname():
    return(__name__)
