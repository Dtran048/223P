def addition(left, right):
    if left.isdigit() == False or right.isdigit() == False:
        return("input valid numbers")
    return(left + right)

def subtraction(left, right):
    if left.isdigit() == False or right.isdigit() == False:
        return("input valid numbers")
    return(left - right)

def multiplication(left, right):
    if left.isdigit() == False or right.isdigit() == False:
        return("input valid numbers")
    return(left * right)

def division(left, right):
    if left.isdigit() == False or right.isdigit() == False:
        return("input valid numbers")
    return(left / right)

